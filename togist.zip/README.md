##togist

**Create a gist on github**

*Select text

*Right click 

*togist 

__Creates a public gist and opens a new tab with that gist__

